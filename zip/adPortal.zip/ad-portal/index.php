<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>AD-portal</title>
  <!--  meta tag for mobile -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--   Jqery -->
  <script src="LibrariesAndFrameworks/jquery-3.3.1.min.js"></script>
  <!-- bootstrap css CDN-->
  <link  rel="stylesheet" href="LibrariesAndFrameworks/bootstrap.min.css">
  <!--  My css file -->
  <link href="css/style.css" rel="stylesheet">
</head>
<body>

<!-- for ajax full page reloading -->
<?php include 'body.php';?> 

</body>
</html>

