<?php 
$servername = "localhost";
$username = "root";
$serverpassword = "root";
$dbname = "users";;
?>