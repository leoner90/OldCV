<!-- CAROUSEL + MAIN PAGE TEXT -->
<div class="myCarousel , carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
  <li data-target=".myCarousel" data-slide-to="0" class="active"></li>
  <li data-target=".myCarousel" data-slide-to="1"></li>
  <li data-target=".myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="img/mainPage-job.jpg" alt="1" style="width:9000px; height: 250px;">
    </div>
    <div class="item">
      <img src="img/mainPage-car.jpg" alt="2" style="width:9000px; height: 250px;">
    </div>  
    <div class="item">
      <img src="img/mainPage-home.jpg" alt="3" style="width:9000px; height: 250px;">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href=".myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>

  <a class="right carousel-control" href=".myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<br>
<span>
  <ul style="padding: 30px;list-style-type:circle; ">
     <li>Is it time for new Job?</li>
     <li>Or  new car?</li>
     <li>Mayby for your new house or flat?</li>
   
    <h2 style="text-align:center;font-weight: bold;text-shadow: 2px 2px blue;">Anyway you are in a right place !! </h2>
    <li>Select from existing ads </li>
    <li>Or make your own  </li>
    <img style=" -webkit-filter: contrast(3); filter: contrast(3);" class="  img-responsive" src="img/free.png" width="150px" height="150px;" ">
  </ul>
</span>

<!-- active collor in case of reload or first visit -->
<script type="text/javascript">
  activeColor('.main')
</script>